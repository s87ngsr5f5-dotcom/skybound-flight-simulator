# 220

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/220
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian (Yves) Tolosa, July 2018

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2018-07-29 Yves Tolosa-Joas: Added new AI Model Airbus A220-300 (Bombardier CS3) + Default Livery + Paintkit
- 2018-07-30 Yves Tolosa-Joas: Updated Condition for Beacon Lightning on AI A220-300 model
- 2018-08-01 Yves Tolosa-Joas: Added Air Baltic A220 Livery, Updated Traffic to JUN 2018
- 2018-08-01 Yves Tolosa-Joas: Added Swiss A220-300 Livery
- 2018-08-01 Yves Tolosa-Joas: Updated AI A220-300 Cockpit Cut, Mapping and Texture
- 2018-08-02 Yves Tolosa-Joas: Removed Directory Transversal
- 2018-08-02 Yves Tolosa-Joas: Added Korean Livery to A220-300 AI model
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Airbus AI Aircrafts
- 2020-06-06 Yves Tolosa-Joas: Compressed AI 220 textures with TinyPng
- 2021-06-02 Yves Tolosa-Joas: Remapped Belly & Updated Existing Textures
- 2021-06-02 Yves Tolosa-Joas: Updated Traffic and Liveries for Delta Airlines
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
