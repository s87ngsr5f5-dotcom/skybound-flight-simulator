# SF3

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/SF3
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian Tolosa

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy
- Karel Klimeš

## History

- 2020-02-07 Yves Tolosa-Joas: New AI version of Saab 340 aircraft
- 2020-03-27 Yves Tolosa-Joas: Updated Objects Names for Easier Warnings Troubleshooting
- 2020-03-27 Yves Tolosa-Joas: LoganAir Livery for Saab 340
- 2020-05-07 Yves Tolosa-Joas: Fixed Saab 340 XML for missing Gear Object
- 2020-07-14 Yves Tolosa-Joas: Traffic and Livery for Airest Cargo
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
