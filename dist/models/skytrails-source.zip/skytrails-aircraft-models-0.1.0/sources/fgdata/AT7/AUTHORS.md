# AT7

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/AT7
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian Tolosa

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Karel Klimeš

## History

- 2017-01-14 Yves Tolosa-Joas: New ATR 72-500 AI Model with Paintkit & Default Liveries
- 2017-01-14 Yves Tolosa-Joas: Liveries for AI ATR 72-500 By Brett Harrison. AerLingus AirNewZeland Hop! & virginAustralia
- 2017-02-01 Yves Tolosa-Joas: AT7 332 & 333 Liveries by Brett Harrisson for Fiji, BlueIslands, CSA, Cebu, EtihadRegional, Flybe
- 2017-03-01 Yves Tolosa-Joas: Liveries by Brett Harrison for A330-300, ATR72 & ATR42 (CSA, Air Tahiti, SAS)
- 2017-06-05 Yves Tolosa-Joas: LOT, Vueling TAP and Wideroe Liveries by Brett Harrison for 733 738 319 321 AT7 and Dash 8
- 2017-06-23 Yves Tolosa-Joas: Air Mauritius Liveries for ATR 72 & A319
- 2017-06-24 Yves Tolosa-Joas: Air Madagascar AI Liveries for ATR 72-500, A340-300 & B737-800
- 2017-06-28 Yves Tolosa-Joas: AI Liveries Update by Brett Harrison
- 2017-08-11 Yves Tolosa-Joas: Nordic Regional AT7 Texture for Finnair Traffic file
- 2017-08-23 Yves Tolosa-Joas: Added Vietnam Airlines Liveries for new models ATR 72 & B787-900
- 2017-11-14 Yves Tolosa-Joas: Updated UTair Traffic by SP-KOK with Liveries by BecOzIcan and Gooneybird
- 2017-11-14 Yves Tolosa-Joas: Relocated UTair livery for ATR 70
- 2017-12-03 Yves Tolosa-Joas: Adjusted AI Models Material to cater for Lightmap
- 2017-12-31 Yves Tolosa-Joas: Added new Tarom AI Liveries
- 2018-02-01 Yves Tolosa-Joas: Added Traffic and Models for Air Caledonie, new AI Airline
- 2018-05-16 Yves Tolosa-Joas: Added Air Vanuatu AI Fleet and Traffic File for weekly movements of JAN 2018
- 2018-05-20 Yves Tolosa-Joas: Added ATR-72 to Air Algerie AI fleet. Updated Traffic to Timetable of MAy 2018
- 2018-06-10 Yves Tolosa-Joas: Added Nordica Livery for ATR42 by Brett Harrison
- 2018-06-21 Yves Tolosa-Joas: Added Livery and Traffic for TunisAirExpress
- 2018-07-17 Yves Tolosa-Joas: Added Livery & July 2018 traffic for Royal Air Maroc Express
- 2018-07-21 Yves Tolosa-Joas: Added Traffic & Liveries for Astral Airlines
- 2018-08-05 Yves Tolosa-Joas: Added Braathens Regional Liveries by Brett Harrison
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on ATR AI Aircrafts
- 2018-08-05 Yves Tolosa-Joas: Added LightMap
- 2018-08-07 Yves Tolosa-Joas: Added Liveries & Traffic for Israir Airlines
- 2019-01-27 Yves Tolosa-Joas: Air Corsica Liveries for AT7 and A320 AI models
- 2019-01-28 Yves Tolosa-Joas: Updated AT7 AI model. Simplified Tail. Reduced Vertices. UV Mapping adjusted
- 2019-01-28 Yves Tolosa-Joas: Binter Cabo Verde Livery for AT7 AI Model
- 2019-01-28 Yves Tolosa-Joas: AT7 Cabo Verde command file missing from previous commit
- 2019-02-03 Yves Tolosa-Joas: Binter Canarias Livery for AI AT7
- 2019-02-09 Yves Tolosa-Joas: CanaryFly Texture for ATR 700-400 AI model
- 2020-02-28 Yves Tolosa-Joas: Added Air Europa Express AI Liveries
- 2020-03-07 Yves Tolosa-Joas: Added AI Liveries Air Caraibes
- 2020-03-10 Yves Tolosa-Joas: Updated ATR42 Air Tahiti Livery and Remapped Trafic File
- 2020-03-16 Yves Tolosa-Joas: Updated Traffic and AI Liveries for Aeromar Mexico
- 2020-04-05 Yves Tolosa-Joas: Added LoganAir AI Liveries
- 2020-05-10 Yves Tolosa-Joas: Corrected Air Tahiti AT7 Propeller Colour
- 2020-05-10 Yves Tolosa-Joas: Corrected Virgin Australia AT7 livery for light reflection
- 2020-05-24 Yves Tolosa-Joas: Liveries and Traffic for Pakistsn Intl
- 2020-08-22 Yves Tolosa-Joas: Added AT7 Windrose livery
- 2021-01-07 Yves Tolosa-Joas: Added AI Liveries and traffic for UNI Air Japan
- 2021-08-21 Yves Tolosa-Joas: Avianca Traffic and Liveries
- 2021-09-18 Yves Tolosa-Joas: Updated Liveries for SAS AI models
- 2021-10-24 Yves Tolosa-Joas: Updated Traffic and Liveries for Eastern Airways UK
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
