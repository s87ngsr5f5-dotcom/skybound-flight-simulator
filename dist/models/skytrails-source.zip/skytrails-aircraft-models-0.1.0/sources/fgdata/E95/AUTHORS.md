# E95

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/E95
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian(Yves) Tolosa, Original Model Innis Cunningham

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2019-04-28 Yves Tolosa-Joas: Cleaned ERJ 195 AI model. Changed name to IATA. Added Navigaton Lights and Lightmap. Corrected Liveries for Windows and Doors size and spacing.
- 2019-04-28 Yves Tolosa-Joas: Liveries for Updated ERJ 195 AI model
- 2019-05-05 Yves Tolosa-Joas: New E95 Liveries Lufthansa Group
- 2020-02-28 Yves Tolosa-Joas: Added Air Europa Express AI Liveries
- 2021-01-19 Yves Tolosa-Joas: Updated Belavia AI ERJ195 Livery to new colour scheme
- 2021-05-05 Yves Tolosa-Joas: Updated Liveries and Traffic for TAP and TAP Express
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
