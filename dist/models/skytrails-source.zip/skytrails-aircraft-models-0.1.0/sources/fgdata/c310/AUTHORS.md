# c310

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/c310
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- (none named)

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Joshua Murphy

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
