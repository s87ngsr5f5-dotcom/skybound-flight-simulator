# A380

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/A380
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian(Yves) Tolosa. July 2016

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Yves Tolosa-Joas
- James Turner
- Stuart Buchanan
- Joshua Murphy

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-07-29 Yves Tolosa-Joas: new Airbus AI model & Liveries for all Active Operators at 01AUG16
- 2016-12-17 Yves Tolosa-Joas: Fix Gear Retract Speed
- 2017-09-17 Yves Tolosa-Joas: Navigation Lights, Strobes, Beacons and Lightmap for A380 AI Model
- 2017-09-23 Yves Tolosa-Joas: AI 380 Ligmapt fix File name Capitalization
- 2017-10-02 James Turner: Fix file names on behalf of BecOzIcan
- 2017-12-03 Yves Tolosa-Joas: Adjusted AI Models Material to cater for Lightmap
- 2017-12-03 Yves Tolosa-Joas: Extend Lightmap Effect to Gear Object in AI Models
- 2017-12-06 Yves Tolosa-Joas: Smoothed Lightmap Tail Halo for AI a380-800
- 2018-01-03 James Turner: Fix capitalization of Qantas A380 livery
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Airbus AI Aircrafts
- 2019-03-31 Yves Tolosa-Joas: Added Airbus Livery as Default to A380 AI model
- 2019-05-05 Yves Tolosa-Joas: Livery update to New Design & Colors for Lufthansa AI Fleet
- 2020-04-12 Yves Tolosa-Joas: Removed deprecated AI 380 model and liveries
- 2020-08-16 Stuart Buchanan: Standard gear and light properties for Airbus AI.
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
