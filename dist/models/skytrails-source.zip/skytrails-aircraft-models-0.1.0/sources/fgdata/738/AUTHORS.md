# 738

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/738
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Brett Harrison

## Contributors (fgdata history of this folder)

- James Turner
- Olivier JACQ
- Yves Tolosa-Joas
- Karel Klimeš

## History

- 2015-10-18 James Turner: Boeing 737-800 AI model and traffic updates.
- 2016-02-08 Olivier JACQ: Committing updates and fixes by Brett Harrison, gooneybird. Fixing liveries, replacing missing aircrafts by existing ones, Updating models and liveries (Ian Tolosa), Updating traffic for DLH and EVA (Ian Tolosa).
- 2016-07-16 Yves Tolosa-Joas: Updated Ukraine Intl Liveries and Traffic File.
- 2016-11-29 Yves Tolosa-Joas: Traffic from DEC 2016 Timetable & Liveries for 777-300 & 737 NG
- 2017-03-23 Yves Tolosa-Joas: Updated Ukraine Intl Liveries 737-300, 737-800, 767-300
- 2017-04-02 Yves Tolosa-Joas: EL AL traffic file update by Marcin Luzniar
- 2017-06-05 Yves Tolosa-Joas: LOT, Vueling TAP and Wideroe Liveries by Brett Harrison for 733 738 319 321 AT7 and Dash 8
- 2017-06-24 Yves Tolosa-Joas: Air Madagascar AI Liveries for ATR 72-500, A340-300 & B737-800
- 2017-08-06 Yves Tolosa-Joas: Traffic and Liveries for Travel Service Czech Republic
- 2017-09-21 Yves Tolosa-Joas: Belavia AI Liveries by Brett Harrison
- 2017-09-25 Yves Tolosa-Joas: AirTransat SEP 2017 update
- 2017-11-14 Yves Tolosa-Joas: Updated UTair Traffic by SP-KOK with Liveries by BecOzIcan and Gooneybird
- 2017-11-26 Yves Tolosa-Joas: Norwegian AI Liveries 738 788 789
- 2017-12-25 Yves Tolosa-Joas: Added BlueAir Liveries
- 2017-12-31 Yves Tolosa-Joas: Added new Tarom AI Liveries
- 2018-01-01 Yves Tolosa-Joas: New FlyDubai 738 Livery by Brett
- 2018-02-05 Yves Tolosa-Joas: Added Air Niugini AI aircrafts and traffic
- 2018-02-09 Yves Tolosa-Joas: Added SunExpress livery for 738 AI model
- 2018-03-17 Yves Tolosa-Joas: New Livery and Traffic for AnadoluJet
- 2018-03-23 Yves Tolosa-Joas: Added Liveries and Traffic for new AI Airline Luxair
- 2018-04-13 Yves Tolosa-Joas: Added Iraqi Airways AI Fleet and Traffic
- 2018-04-16 Yves Tolosa-Joas: Added AT5 & 738 NordStar Liveries, Updated Traffic to APR 2018 timetable
- 2018-05-16 Yves Tolosa-Joas: Added Air Vanuatu AI Fleet and Traffic File for weekly movements of JAN 2018
- 2018-06-03 Yves Tolosa-Joas: Updated S7 Siberian Traffic. Added 738 and E70 AI Models Liveries
- 2018-06-24 Yves Tolosa-Joas: Added Livery and Traffic for Pobeda
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Boeing AI Aircrafts
- 2018-08-10 Yves Tolosa-Joas: Added Smartwing Livery & updated Travel Services traffic
- 2018-08-12 Yves Tolosa-Joas: Added Corendon Liveries by Brett Harrison
- 2019-01-26 Yves Tolosa-Joas: El Al UP 737-800 Livery by legoboyvdlp
- 2019-11-24 Yves Tolosa-Joas: Added Icelandair liveries for 738 739 763 AI models
- 2019-12-01 Yves Tolosa-Joas: Added Westjet 738 AI Livery
- 2019-12-28 Yves Tolosa-Joas: Updated AI Liveries for Alaska Airlines
- 2020-02-28 Yves Tolosa-Joas: Added Air Europa AI Liveries
- 2020-03-09 Yves Tolosa-Joas: Corrected Material and emissive
- 2020-03-11 Yves Tolosa-Joas: Updated AAL 738 colours for consistency across AI fleet
- 2020-03-12 Yves Tolosa-Joas: Re-aligned entire American Airlines AI Fleet livery colour scheme
- 2020-03-29 Yves Tolosa-Joas: Added SkyUp AI Liveries
- 2020-04-30 Yves Tolosa-Joas: Updated AI Liveries and Traffic for Rossiya
- 2020-05-20 Yves Tolosa-Joas: Rwandair AI Liveries and Traffic Update
- 2020-06-14 Yves Tolosa-Joas: AI Liveries and Traffic for Turkmenistan Airlines
- 2020-12-24 Yves Tolosa-Joas: Added AI Traffic and Livery for Solaseed Japan
- 2021-01-15 Yves Tolosa-Joas: AI Liveries and Traffic for Southern Air Cargo
- 2021-05-18 Yves Tolosa-Joas: Updated Traffic and liveries for United Airlines
- 2021-09-18 Yves Tolosa-Joas: Updated Liveries for SAS AI models
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
