# 777

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/777
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian(Yves) Tolosa. September 2016

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Olivier JACQ
- Yves Tolosa-Joas
- James Turner
- Richard Harrison
- Joshua Murphy
- Karel Klimeš

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-02-08 Olivier JACQ: Updates and fixes by Gooneybird. Fixing wrong XML attributions for Aircrafts, adding new liveries for Air Berlin, Air China, fixing traffic files, new traffic files and liveries for Thomas Cook
- 2016-02-08 Olivier JACQ: Committing updates and fixes by Brett Harrison, gooneybird. Fixing liveries, replacing missing aircrafts by existing ones, Updating models and liveries (Ian Tolosa), Updating traffic for DLH and EVA (Ian Tolosa).
- 2016-08-06 Yves Tolosa-Joas: AI-787-8 updated liveries AI-777-Thai fixed broken XML
- 2016-09-17 James Turner: New 777 livery
- 2016-09-19 Yves Tolosa-Joas: Resized Asiana 777 livery
- 2016-11-08 Yves Tolosa-Joas: New 777 AI Models : 777-200LR 777-300ER and 777-200 Freighter
- 2016-11-08 Yves Tolosa-Joas: Emirates Traffic & Liveries Update as per Timetable of OCT 2016
- 2016-11-09 Yves Tolosa-Joas: Air France Update with new 777 AI models and associated Traffic file changes
- 2016-11-19 Yves Tolosa-Joas: Added new 777s Thai Airways models and repointed Traffic File
- 2016-11-14 Yves Tolosa-Joas: New 777 models for Cathay, Adjusted Traffic File, 2016 design for A333-300 livery
- 2016-11-20 Yves Tolosa-Joas: ew 777 models for Qatar, Adjusted Traffic File
- 2016-11-29 Yves Tolosa-Joas: Traffic from DEC 2016 Timetable & Liveries for 777-300 & 737 NG
- 2016-11-30 Yves Tolosa-Joas: ETD Facets of Abu Dhabi Liveries for 777 AI models
- 2016-12-04 Yves Tolosa-Joas: SingaporeAir new 777 models and re-pointed Traffic File
- 2016-12-16 Yves Tolosa-Joas: Air India Traffic Timetable week 24NOV16 & 777 Models
- 2017-01-13 Yves Tolosa-Joas: Air New Zealand Fleet Update : Liveries for new 777-200 and 777-300 AI models
- 2017-01-14 Yves Tolosa-Joas: AirCanada AI Fleet Update : New 777-200, 777-300 & ERJ175
- 2017-01-18 Yves Tolosa-Joas: Etihad AI Liveries Update. 777 in new Livery. A320 in old Livery (new does not fir current model mapping). A345 corrected Wings color (metal rather than fuselage)
- 2017-01-21 Yves Tolosa-Joas: Korean Air AI Fleet Update with new 777 and 747 both Pax & Freighters
- 2017-01-24 Yves Tolosa-Joas: Philippines Airlines Fleet Update: 777-300, A321, Dash-8-300 & Dash-8-400 liveries
- 2017-01-24 Yves Tolosa-Joas: Corrected Philipppines 777 texture
- 2017-01-29 Yves Tolosa-Joas: British Airways Liveries for new 777 AI models
- 2017-02-25 Yves Tolosa-Joas: KLM 777-200, 777-300 & 747 Freighter liveries
- 2017-03-30 Yves Tolosa-Joas: EL AL Livery for 777-200 AI model
- 2017-06-21 Yves Tolosa-Joas: Changed 777 AI models Pitch method; from AC Model itself to main XML
- 2017-06-23 Yves Tolosa-Joas: Austrian Airlines Livery for new 777-200
- 2017-06-28 Yves Tolosa-Joas: TAM Brazil AI 777-300 Livery
- 2017-07-25 Yves Tolosa-Joas: Asiana Update. Replaced 777-200 with newest model.
- 2017-07-29 Yves Tolosa-Joas: JAL traffic Update from Timetable for SEP OCT 2017 includes new 777 and 787 models liveries
- 2017-08-07 Yves Tolosa-Joas: New 777-300 Livery for Swiss Airlines
- 2017-08-09 Yves Tolosa-Joas: New Kuwait livery for 777-300
- 2017-08-20 Yves Tolosa-Joas: EuroAlantic 777-200 livery for TAP Traffic
- 2017-09-13 Yves Tolosa-Joas: Updated AI Liveries for China Airlines and Subsidiary Mandarin
- 2017-09-24 Yves Tolosa-Joas: Navigation Lights & Lightmap for AI 777 series
- 2017-12-03 Yves Tolosa-Joas: Adjusted AI Models Material to cater for Lightmap
- 2017-12-03 Yves Tolosa-Joas: Extend Lightmap Effect to Gear Object in AI Models
- 2017-12-09 Yves Tolosa-Joas: Corrected Tail Light Halo for 777-300 AI model
- 2017-12-11 Yves Tolosa-Joas: Replaced 777-300 with latest model in EVA Air Traffic file
- 2018-02-23 Yves Tolosa-Joas: Added Turkish Liveries for freighters and 777-300ER
- 2018-04-13 Yves Tolosa-Joas: Added Iraqi Airways AI Fleet and Traffic
- 2018-05-23 Yves Tolosa-Joas: Added AI 777-200 Ukraine Intl livery
- 2018-07-10 Yves Tolosa-Joas: Updated Traffic & Liveries for Saudia to June 2018 Timetable
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Boeing AI Aircrafts
- 2019-02-09 Yves Tolosa-Joas: Lufthansa Cargo Livery for 777 freighter AI model
- 2019-04-29 Yves Tolosa-Joas: Remapped FWD from Top no to distord long brands Virgin and Air France
- 2019-04-29 Yves Tolosa-Joas: Added Virgin Australia livery for 777-300 AI model
- 2019-10-03 Yves Tolosa-Joas: Added China Southern Boeing & Embraer AI Liveries
- 2019-10-28 Yves Tolosa-Joas: Updated American Airlines AI Liveries
- 2019-11-22 Yves Tolosa-Joas: Updated Air Canada AI fleet to new Black Livery
- 2020-03-12 Yves Tolosa-Joas: Re-aligned entire American Airlines AI Fleet livery colour scheme
- 2020-04-09 Yves Tolosa-Joas: Removed Deprecated ANA textures
- 2020-04-09 Yves Tolosa-Joas: Migrated ANA Traffic Off older 777
- 2020-04-09 Yves Tolosa-Joas: Removed Deprecated 777-200 liveries
- 2020-04-09 Yves Tolosa-Joas: Removed Deprecated 777 textures
- 2020-04-09 Yves Tolosa-Joas: Migrated AirChina traffic off older 777 model
- 2020-04-09 Yves Tolosa-Joas: Corrected AirChina Livery Missing Door 1
- 2020-04-09 Yves Tolosa-Joas: Removed Deprecated 777-300 Liveries
- 2020-04-09 Yves Tolosa-Joas: Migrated UAL Traffic Off deprecated 777 AI model
- 2020-04-10 Yves Tolosa-Joas: Migrated Egyptair AI traffic Off old 777 model
- 2020-04-10 Yves Tolosa-Joas: Fixed CCA 77W AI texture - Belly Colour
- 2020-04-10 Yves Tolosa-Joas: Removed deprecated 777 model and textures
- 2020-04-10 Yves Tolosa-Joas: Corrected ANA 777 AI models liveries - Missing Belly colour
- 2020-04-10 Yves Tolosa-Joas: Removed deprecated Alitalia 777 model & livery
- 2020-04-10 Yves Tolosa-Joas: Migrated Alitalia off older 777 AI model
- 2020-04-10 Yves Tolosa-Joas: Mirated Delta Off old 777 AI model
- 2020-04-10 Yves Tolosa-Joas: Removed deprecated 777 AI model
- 2020-04-30 Yves Tolosa-Joas: Updated AI Liveries and Traffic for Rossiya
- 2020-05-24 Yves Tolosa-Joas: Liveries and Traffic for Pakistsn Intl
- 2020-06-14 Yves Tolosa-Joas: AI Liveries and Traffic for Turkmenistan Airlines
- 2021-01-15 Yves Tolosa-Joas: AI Liveries and Traffic for Southern Air Cargo
- 2021-04-14 Yves Tolosa-Joas: Liveries & traffic files fixes for ANA AirHongKong & AirChina.
- 2021-04-28 Yves Tolosa-Joas: Updated ANA Traffic. Includes PAX and Cargo as well as ANA Wings and Air Japan
- 2021-05-18 Yves Tolosa-Joas: Updated Traffic and liveries for United Airlines
- 2021-06-28 Yves Tolosa-Joas: Updated Fleet and Traffic for AirBridgeCargo
- 2021-08-15 Yves Tolosa-Joas: Removed Deprecated LAN & TAM Aircrafts and Liveries now replaced by LATAM
- 2021-10-18 Richard Harrison: AI: added fallback model for 777 (instead of AF 777)
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
