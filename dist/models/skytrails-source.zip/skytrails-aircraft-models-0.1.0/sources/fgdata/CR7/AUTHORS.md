# CR7

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/CR7
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian (Yves) Tolosa, November 2019

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2019-12-01 Yves Tolosa-Joas: Added CRJ-700 AI Model and Liveries
- 2020-03-17 Yves Tolosa-Joas: Updated United CRJ to new Evo livery. Remapped traffic to latest models
- 2020-12-18 Yves Tolosa-Joas: Added AI Traffic and Livery for Ibex Japan
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
