# FK9MK2

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/FK9MK2
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- (none named)

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Edward d'Auvergne

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-01-06 Edward d'Auvergne: Fixes for all PNG files with corrupted ICC color profiles.
