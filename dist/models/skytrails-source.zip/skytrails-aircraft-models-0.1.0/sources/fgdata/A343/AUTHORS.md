# A343

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/A343
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- 3D Model Innis Cunningham, UV map liveries Brett Harrison

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Olivier JACQ
- Yves Tolosa-Joas
- Stuart Buchanan
- Karel Klimeš

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-02-08 Olivier JACQ: Committing updates and fixes by Brett Harrison, gooneybird. Fixing liveries, replacing missing aircrafts by existing ones, Updating models and liveries (Ian Tolosa), Updating traffic for DLH and EVA (Ian Tolosa).
- 2017-06-24 Yves Tolosa-Joas: Air Madagascar AI Liveries for ATR 72-500, A340-300 & B737-800
- 2017-12-06 Yves Tolosa-Joas: Added LightMap and Navigation Lights to A340-300 AI Model
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Airbus AI Aircrafts
- 2019-01-25 Yves Tolosa-Joas: Added Edelweiss Livery for A340-300
- 2019-05-05 Yves Tolosa-Joas: Livery update to New Design & Colors for Lufthansa AI Fleet
- 2020-08-16 Stuart Buchanan: Standard gear and light properties for Airbus AI.
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
