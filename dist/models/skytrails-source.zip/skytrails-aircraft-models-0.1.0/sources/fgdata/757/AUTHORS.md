# 757

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/757
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Unknown, modified by Brett Harrison

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Olivier JACQ
- Yves Tolosa-Joas
- Joshua Murphy
- Karel Klimeš

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-02-08 Olivier JACQ: Updates and fixes by Gooneybird. Fixing wrong XML attributions for Aircrafts, adding new liveries for Air Berlin, Air China, fixing traffic files, new traffic files and liveries for Thomas Cook
- 2016-02-08 Olivier JACQ: Updates and fixes by Brett Harrison, gooneybird. Fixing liveries, Aircrafts definitions in traffic files, removing Alpha channels and resizing 757 liverines.
- 2016-02-08 Olivier JACQ: Committing updates and fixes by Brett Harrison, gooneybird. Fixing liveries, replacing missing aircrafts by existing ones, Updating models and liveries (Ian Tolosa), Updating traffic for DLH and EVA (Ian Tolosa).
- 2017-10-20 Yves Tolosa-Joas: Jet2 Liveries by Brett Harrison
- 2017-12-24 Yves Tolosa-Joas: Added Condor AI Liveries
- 2018-04-02 Yves Tolosa-Joas: New Traffic and Liveries for Azrbaijan Airlines
- 2018-06-25 Yves Tolosa-Joas: Air Astana Update, Liveries by Brett Harrison, Traffic by Marcin Kuzniar
- 2018-09-26 Yves Tolosa-Joas: Arkia Liveries by Brett Harrison
- 2020-03-22 Yves Tolosa-Joas: Added Uzbekistan AI Liveries
- 2020-04-12 Yves Tolosa-Joas: Removed deprecated 757 AI model and Liveries
- 2020-06-14 Yves Tolosa-Joas: AI Liveries and Traffic for Turkmenistan Airlines
- 2021-01-10 Yves Tolosa-Joas: added Traffic and Liveries for Air Transport Intl including flights operated for DHL and Amazon Air
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
