# 747

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/747
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian(Yves) Tolosa. Apr 2016

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2016-04-24 Yves Tolosa-Joas: New 747-400 AI Model with Paintkit and 16 Liveries. 13 Updated Traffic Files repointed to new model path. Garuda and Malaysian current traffic files do not include 747 model hence no update.
- 2016-05-28 Yves Tolosa-Joas: Update to 747 AI Model. New Model 747-400 Freighter. Liveries for Cathay and Singapore 747 Cargo. KuwaitAirways Livery for 744 pax model
- 2016-06-04 Yves Tolosa-Joas: Updated 747 Cargo with Shorter Upper Deck and new UV Map
- 2016-07-05 Yves Tolosa-Joas: Kuwait & Egyptair Traffic Files & AI Liveries. AI 747 Cargo Paintkit.
- 2016-09-17 Yves Tolosa-Joas: 747 & 767 Freighter models and liveries.
- 2016-09-19 Yves Tolosa-Joas: Resized Asiana 747 Liveries
- 2016-11-08 Yves Tolosa-Joas: Emirates Traffic & Liveries Update as per Timetable of OCT 2016
- 2016-12-11 Yves Tolosa-Joas: Air India Textures Update. Airbus by Brett Harrison, Boeing by Ian Tolosa
- 2017-01-15 Yves Tolosa-Joas: 747-400 Cargo AI Model & Liveries Update: Top of Fuselage remapped from above to avoid bleeding colors (from side mapping)
- 2017-01-19 Yves Tolosa-Joas: Missing XML for Etihad Fleet update
- 2017-01-21 Yves Tolosa-Joas: Korean Air AI Fleet Update with new 777 and 747 both Pax & Freighters
- 2017-01-26 Yves Tolosa-Joas: AI 747 Model Update. Re-cut Upper deck aft
- 2017-02-03 Yves Tolosa-Joas: 747 AI models Corrected Speed for Gear Retraction
- 2017-02-21 Yves Tolosa-Joas: Fix to 747-200 Cargo Material
- 2017-02-25 Yves Tolosa-Joas: New AI 747-400BCF Livery Martinair for KLM
- 2017-02-25 Yves Tolosa-Joas: KLM 777-200, 777-300 & 747 Freighter liveries
- 2017-03-27 Yves Tolosa-Joas: Remapped 747-400 AI Model (Top of fuselage)
- 2017-03-27 Yves Tolosa-Joas: 747-400 Liveries for new model mapping
- 2017-03-27 Yves Tolosa-Joas: Remapped 747-400 Freighter (Top Fuselage) and updated Liveries
- 2017-03-29 Yves Tolosa-Joas: Retouched Belly Mapping on 747-400s AI models
- 2017-03-29 Yves Tolosa-Joas: EL AL Liveries for 747-400 models
- 2017-09-13 Yves Tolosa-Joas: Updated AI Liveries for China Airlines and Subsidiary Mandarin
- 2017-11-11 Yves Tolosa-Joas: NavLights and LightMap for AI 747 Series
- 2017-12-03 Yves Tolosa-Joas: Adjusted AI Models Material to cater for Lightmap
- 2017-12-03 Yves Tolosa-Joas: Extend Lightmap Effect to Gear Object in AI Models
- 2018-04-13 Yves Tolosa-Joas: Added Iraqi Airways AI Fleet and Traffic
- 2018-04-16 Yves Tolosa-Joas: Added Liveries and Traffic APR 18 for Corsair Intl LFPO
- 2018-05-25 Yves Tolosa-Joas: Corrected Erroneous AI 747 Model(s) Description
- 2018-06-03 Yves Tolosa-Joas: Updated AirBridgeCargo Traffic and 747-400F Livery
- 2018-06-03 Yves Tolosa-Joas: Added Traffic and 747-400F Livery for CargoLogicAir
- 2018-07-10 Yves Tolosa-Joas: Updated Traffic & Liveries for Saudia to June 2018 Timetable
- 2018-07-15 Yves Tolosa-Joas: Updated Liveries & Traffic for Royal Air Maroc to JUL 18
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Boeing AI Aircrafts
- 2018-09-16 Yves Tolosa-Joas: Added Liveries for Cargolux and Cargolux Italia
- 2018-12-02 Yves Tolosa-Joas: Added New 747-8 Freighter AI Model with Boeing Default Livery
- 2018-12-08 Yves Tolosa-Joas: Fixed Texture Mapping and reduced Vertex footprint for 74N AI Model
- 2018-12-08 Yves Tolosa-Joas: Added UPS Textures for 767 and 744 models
- 2018-12-08 Yves Tolosa-Joas: Added Textures to 747-8F AI model
- 2018-12-08 Yves Tolosa-Joas: Removed erroneous UPS file in 747 AI main folder
- 2018-12-08 Yves Tolosa-Joas: Added AI 747 UPS Textures
- 2019-05-05 Yves Tolosa-Joas: Livery update to New Design & Colors for Lufthansa AI Fleet
- 2019-10-03 Yves Tolosa-Joas: Added China Southern Boeing & Embraer AI Liveries
- 2020-04-30 Yves Tolosa-Joas: Updated AI Liveries and Traffic for Rossiya
- 2020-06-01 Yves Tolosa-Joas: Liveries and Traffic for Western Global Cargo
- 2020-06-06 Yves Tolosa-Joas: Traffic and AI Liveries for ASL Belgium Cargo
- 2020-07-05 Yves Tolosa-Joas: Corrected Tail Mapping
- 2020-07-05 Yves Tolosa-Joas: Liveries and Traffic for Polar Air Cargo
- 2021-10-14 Yves Tolosa-Joas: Added Traffic and Livery for SykyLeaseCargo
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
