# DH4

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/DH4
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian Tolosa

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2020-04-29 Yves Tolosa-Joas: Revamped Dash 8 Q400 AI Model
- 2020-04-29 Yves Tolosa-Joas: Added Livery and Traffic for Jambojet
- 2020-04-30 Yves Tolosa-Joas: Replaced QantasLink Dash8 with new model
- 2020-05-02 Yves Tolosa-Joas: Remapped Dash8 to new model
- 2020-05-08 Yves Tolosa-Joas: Updated Tail Design and Mapping
- 2020-05-08 Yves Tolosa-Joas: Remapped Croatia Traffic to new Dash8-Q400
- 2020-05-09 Yves Tolosa-Joas: Remapped existing Luxair Traffic to new DH4 AI model
- 2020-05-10 Yves Tolosa-Joas: Remapped WestJet Encore traffic to new Dash8 AI model
- 2020-05-11 Yves Tolosa-Joas: Rebasing DH4 (2)
- 2020-05-13 Yves Tolosa-Joas: Added Wideroe Texture for new Dash8-q4
- 2020-05-20 Yves Tolosa-Joas: Rwandair AI Liveries and Traffic Update
- 2020-05-23 Yves Tolosa-Joas: Corrected lightmap intensity, windows borders and tail hallo
- 2020-12-15 Yves Tolosa-Joas: Added AI Livery and traffic for ANA Wings
- 2021-05-01 Yves Tolosa-Joas: Added Liveries and Traffic for SATA Air Acores and subsidiary Azores Airlines
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
