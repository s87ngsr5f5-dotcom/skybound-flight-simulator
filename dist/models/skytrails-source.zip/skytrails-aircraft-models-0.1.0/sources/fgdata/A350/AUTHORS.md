# A350

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/A350
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian(Yves) Tolosa. August 2017

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- James Turner
- Stuart Buchanan
- Joshua Murphy
- Florent Rougon

## History

- 2017-08-19 Yves Tolosa-Joas: New AI Model Airbus A350-900 with Paintkit and Liveries for Aircrafts delivered to date
- 2017-09-13 Yves Tolosa-Joas: Updated AI Liveries for China Airlines and Subsidiary Mandarin
- 2017-09-17 Yves Tolosa-Joas: Navigation Lights, Strobes, Beacons and Lightmap for A350-900 AI Model
- 2017-09-23 Yves Tolosa-Joas: AI 359 Lightmap Fix Capitalisation in File Names
- 2017-10-02 James Turner: Fix file names on behalf of BecOzIcan
- 2017-12-03 Yves Tolosa-Joas: Changed Tail Light Halo to Spherical
- 2017-12-03 Yves Tolosa-Joas: Adjusted AI Models Material to cater for Lightmap
- 2017-12-03 Yves Tolosa-Joas: Extend Lightmap Effect to Gear Object in AI Models
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Airbus AI Aircrafts
- 2018-08-25 Yves Tolosa-Joas: Updated Traffic to AUG18 timetable. Added 359 and 33X liveries. Updated 332 Livery to new colors
- 2019-05-05 Yves Tolosa-Joas: Livery update to New Design & Colors for Lufthansa AI Fleet
- 2019-09-29 Yves Tolosa-Joas: Airbus Liveries for China Southern
- 2019-09-30 Yves Tolosa-Joas: Corrected Brand Side Chinese Characters (flipped)
- 2020-03-07 Yves Tolosa-Joas: Added AI Liveries Air Caraibes
- 2020-05-27 Yves Tolosa-Joas: AI Traffic & Livery for FrenchBee
- 2020-08-16 Stuart Buchanan: Standard gear and light properties for Airbus AI.
- 2021-06-02 Yves Tolosa-Joas: Updated Traffic and Liveries for Delta Airlines
- 2021-08-15 Yves Tolosa-Joas: Removed Deprecated LAN & TAM Aircrafts and Liveries now replaced by LATAM
- 2021-09-11 Yves Tolosa-Joas: New Livery for A350 Scandinavian Airlines
- 2021-09-18 Yves Tolosa-Joas: Updated Liveries for SAS AI models
- 2022-03-18 Yves Tolosa-Joas: Added Air Mauritius Livery for A350 AI model
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
- 2025-07-28 Florent Rougon: Fix the two invalid PropertyList includes
- 2025-07-29 Florent Rougon: Avoid ../ paths in an AI/Aircraft/A350 PropertyList include
