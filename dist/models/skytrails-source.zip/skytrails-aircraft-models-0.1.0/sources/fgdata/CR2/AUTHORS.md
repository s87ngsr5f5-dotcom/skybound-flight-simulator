# CR2

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/CR2
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian (Yves) Tolosa, December 2019

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2019-12-17 Yves Tolosa-Joas: Added new Version of Bombardier CRJ200 AI model
- 2019-12-20 Yves Tolosa-Joas: Added Air Canada Jazz for new CRJ 200 AI model
- 2019-12-20 Yves Tolosa-Joas: Added Belavia Livery for new CRJ 200 AI Model. Remapped Traffic File
- 2019-12-20 Yves Tolosa-Joas: Added Rusline Livery for new CRJ 200 AI Model. Remapped Traffic File
- 2019-12-20 Yves Tolosa-Joas: Added South African Express Livery for AI CRJ200 model
- 2019-12-20 Yves Tolosa-Joas: Corrected Winglets Mapping for CRJ200 AI model. Removed nose Gear Covers
- 2019-12-21 Yves Tolosa-Joas: Corrected Rusline CR2 livery missing RHS
- 2019-12-28 Yves Tolosa-Joas: Added Delta livery for new CRJ 200 AI model
- 2020-01-05 Yves Tolosa-Joas: Added United Express Livery for CRJ 200 AI model
- 2020-03-17 Yves Tolosa-Joas: Updated United CRJ to new Evo livery. Remapped traffic to latest models
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
