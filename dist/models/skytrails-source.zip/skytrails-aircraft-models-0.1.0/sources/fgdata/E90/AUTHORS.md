# E90

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/E90
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian(Yves) Tolosa

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2017-03-19 Yves Tolosa-Joas: New AI Model Embraer ERJ 190 with Paintkit and liveries Default, Helvetic Airways and Finnair
- 2017-03-26 Yves Tolosa-Joas: ERJ90 AI model update, new Tail and Nacelles + Adjusted Paintkit
- 2017-03-26 Yves Tolosa-Joas: New Liveries for ERJ90 AI model
- 2017-03-26 Yves Tolosa-Joas: Updated Liveries AI ERJ90 with Nacelles Texture
- 2017-09-13 Yves Tolosa-Joas: Updated AI Liveries for China Airlines and Subsidiary Mandarin
- 2017-12-03 Yves Tolosa-Joas: Adjusted AI Models Material to cater for Lightmap
- 2018-02-18 Yves Tolosa-Joas: Kenya Airways Models and Trafic Update
- 2018-03-21 Yves Tolosa-Joas: Updated Bulgaria Air Fleet and Traffic
- 2018-04-02 Yves Tolosa-Joas: New Traffic and Liveries for Azrbaijan Airlines
- 2018-05-10 Yves Tolosa-Joas: AeroMexico Liveries and Traffic Updateed to MAR 2108
- 2018-05-19 Yves Tolosa-Joas: Added Air Moldova AI Liveries and Traffic
- 2018-06-25 Yves Tolosa-Joas: Air Astana Update, Liveries by Brett Harrison, Traffic by Marcin Kuzniar
- 2018-07-15 Yves Tolosa-Joas: Updated Liveries & Traffic for Royal Air Maroc to JUL 18
- 2018-09-26 Yves Tolosa-Joas: Arkia Liveries by Brett Harrison
- 2019-04-03 Yves Tolosa-Joas: LOT Polish AI liveries for E90 and Dash8 by Marcin
- 2019-04-23 Yves Tolosa-Joas: Added LightMap and ALS Navigation Lights to Embraer ERJ190 AI Model
- 2019-04-27 Yves Tolosa-Joas: Added Hop! Livery to ERJ 190 AI Model
- 2019-05-05 Yves Tolosa-Joas: Livery update to New Design & Colors for Lufthansa AI Fleet
- 2019-10-03 Yves Tolosa-Joas: Added China Southern Boeing & Embraer AI Liveries
- 2020-01-01 Yves Tolosa-Joas: Corrected Tail for Misdirected Surface Vertical
- 2020-01-27 Yves Tolosa-Joas: Corrected texture name casing in AC model
- 2020-03-08 Yves Tolosa-Joas: Added JetBlue AI Liveries
- 2021-10-24 Yves Tolosa-Joas: Updated Traffic and Liveries for Eastern Airways UK
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
