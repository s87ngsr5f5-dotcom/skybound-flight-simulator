# DH3

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/DH3
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Ian Tolosa

## Contributors (fgdata history of this folder)

- Yves Tolosa-Joas
- Joshua Murphy

## History

- 2020-05-18 Yves Tolosa-Joas: Added new Dash8 Q300 AI Model and Liveries
- 2020-05-23 Yves Tolosa-Joas: Corrected lightmap intensity, windows borders and tail hallo
- 2025-03-10 Joshua Murphy: Unify all AI/Aircraft to use the same naming scheme.
