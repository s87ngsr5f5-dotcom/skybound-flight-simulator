# ERJ145

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/ERJ145
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Brett Harrison

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Olivier JACQ
- James Turner
- Yves Tolosa-Joas
- Karel Klimeš

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-02-08 Olivier JACQ: Committing updates and fixes by Brett Harrison, gooneybird. Fixing liveries, replacing missing aircrafts by existing ones, Updating models and liveries (Ian Tolosa), Updating traffic for DLH and EVA (Ian Tolosa).
- 2016-08-08 James Turner: New AI liveries from Brett Harrison.
- 2018-05-13 Yves Tolosa-Joas: Added Liveries & Traffic for Windrose Airlines Ukraine
- 2019-11-06 Yves Tolosa-Joas: Updated AmericanEagle livery for ERJ145
- 2020-03-12 Yves Tolosa-Joas: Re-aligned entire American Airlines AI Fleet livery colour scheme
- 2020-03-20 Yves Tolosa-Joas: Remapped United Embraer Legacy to Commercial version ERJ145 and updated livery to new Evo scheme
- 2020-04-05 Yves Tolosa-Joas: Cleaned Up ERJ145 AI model and renamed objects
- 2020-04-05 Yves Tolosa-Joas: Added LoganAir AI Liveries
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
