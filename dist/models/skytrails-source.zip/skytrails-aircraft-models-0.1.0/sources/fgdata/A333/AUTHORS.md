# A333

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/A333
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- 3D Model Innis Cunningham, UV map liveries Brett Harrison

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Olivier JACQ
- James Turner
- Yves Tolosa-Joas
- Stuart Buchanan
- Lars Toenning
- scttgs0
- Karel Klimeš

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-02-08 Olivier JACQ: Committing updates and fixes by Brett Harrison, gooneybird. Fixing liveries, replacing missing aircrafts by existing ones, Updating models and liveries (Ian Tolosa), Updating traffic for DLH and EVA (Ian Tolosa).
- 2016-08-08 James Turner: New AI liveries from Brett Harrison.
- 2016-11-14 Yves Tolosa-Joas: New 777 models for Cathay, Adjusted Traffic File, 2016 design for A333-300 livery
- 2016-12-03 Yves Tolosa-Joas: Oman Air Updated Traffic & Fleet
- 2017-02-01 Yves Tolosa-Joas: AT7 332 & 333 Liveries by Brett Harrisson for Fiji, BlueIslands, CSA, Cebu, EtihadRegional, Flybe
- 2017-03-01 Yves Tolosa-Joas: Liveries by Brett Harrison for A330-300, ATR72 & ATR42 (CSA, Air Tahiti, SAS)
- 2017-06-28 Yves Tolosa-Joas: AI Liveries Update by Brett Harrison
- 2017-09-29 Yves Tolosa-Joas: Air Transat Fleet Livery Update
- 2017-12-05 Yves Tolosa-Joas: Added Navigation Lights and LightMap to AI A330-300
- 2017-12-11 Yves Tolosa-Joas: South African Airways livery for AI A330-300
- 2017-12-23 Yves Tolosa-Joas: Updated Iberia AI Liveries
- 2018-01-26 Yves Tolosa-Joas: Updated Srilankan Traffic and models
- 2018-04-16 Yves Tolosa-Joas: Added Liveries and Traffic APR 18 for Corsair Intl LFPO
- 2018-07-10 Yves Tolosa-Joas: Updated Traffic & Liveries for Saudia to June 2018 Timetable
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Airbus AI Aircrafts
- 2019-05-05 Yves Tolosa-Joas: Livery update to New Design & Colors for Lufthansa AI Fleet
- 2019-10-28 Yves Tolosa-Joas: Updated American Airlines AI Liveries
- 2019-11-22 Yves Tolosa-Joas: Updated Air Canada AI fleet to new Black Livery
- 2020-02-28 Yves Tolosa-Joas: Added Air Europa AI Liveries
- 2020-03-07 Yves Tolosa-Joas: Added AI Liveries Air Caraibes
- 2020-03-12 Yves Tolosa-Joas: Re-aligned entire American Airlines AI Fleet livery colour scheme
- 2020-04-12 Yves Tolosa-Joas: Removed deprecated A333 AI Liveries
- 2020-05-20 Yves Tolosa-Joas: Rwandair AI Liveries and Traffic Update
- 2020-08-16 Stuart Buchanan: Standard gear and light properties for Airbus AI.
- 2021-03-21 Lars Toenning: Add Eurowings A333 livery
- 2023-04-17 scttgs0: [AI/Aircraft] PNG compression and iCCP removal
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
