# A320

Source: https://gitlab.com/flightgear/fgdata/-/tree/d96d5702c3bdeab4befb57b07079c3b4fad2dcce/AI/Aircraft/A320
Licence: GNU GPL v2 (see ../LICENSE.md)

## Authors named in the model files

- Brett Harrison

## Contributors (fgdata history of this folder)

- Torsten Dreyer
- Edward d'Auvergne
- Olivier JACQ
- James Turner
- Yves Tolosa-Joas
- Lars Toenning
- Stuart Buchanan
- scttgs0
- Karel Klimeš

## History

- 2015-03-07 Torsten Dreyer: Readd AI/ Models/ and Scenery/ with clean history
- 2016-01-06 Edward d'Auvergne: Fixes for all PNG files with corrupted ICC color profiles.
- 2016-02-08 Olivier JACQ: Committing updates and fixes by Brett Harrison, gooneybird. Fixing liveries, replacing missing aircrafts by existing ones, Updating models and liveries (Ian Tolosa), Updating traffic for DLH and EVA (Ian Tolosa).
- 2016-08-08 James Turner: New AI liveries from Brett Harrison.
- 2016-11-10 Yves Tolosa-Joas: Royal Brunei Airlines OCT 2016 Traffic File and Liveries
- 2016-12-11 Yves Tolosa-Joas: Air India Textures Update. Airbus by Brett Harrison, Boeing by Ian Tolosa
- 2017-01-18 Yves Tolosa-Joas: Etihad AI Liveries Update. 777 in new Livery. A320 in old Livery (new does not fir current model mapping). A345 corrected Wings color (metal rather than fuselage)
- 2017-06-28 Yves Tolosa-Joas: AI Liveries Update by Brett Harrison
- 2017-08-06 Yves Tolosa-Joas: Traffic and Liveries for Travel Service Czech Republic
- 2017-12-23 Yves Tolosa-Joas: Updated Iberia AI Liveries
- 2017-12-24 Yves Tolosa-Joas: Added Condor AI Liveries
- 2017-12-27 Yves Tolosa-Joas: Added Liveries for Iberia Express AI models
- 2018-01-28 Yves Tolosa-Joas: Added Aicrafts and Traffic for Air Caledonie International
- 2018-01-28 Yves Tolosa-Joas: Added AI A320 Pegasus livery
- 2018-02-08 Yves Tolosa-Joas: Added Black Livery for Air New Zealand A320 and updated Traffic File to Jan 18 Timetable
- 2018-03-21 Yves Tolosa-Joas: Updated Bulgaria Air Fleet and Traffic
- 2018-04-02 Yves Tolosa-Joas: New Traffic and Liveries for Azrbaijan Airlines
- 2018-04-13 Yves Tolosa-Joas: Added Iraqi Airways AI Fleet and Traffic
- 2018-05-13 Yves Tolosa-Joas: Added Liveries & Traffic for Windrose Airlines Ukraine
- 2018-05-19 Yves Tolosa-Joas: Added Air Moldova AI Liveries and Traffic
- 2018-06-16 Yves Tolosa-Joas: Added AI Airline NouvelAir Tunisia
- 2018-06-25 Yves Tolosa-Joas: Air Astana Update, Liveries by Brett Harrison, Traffic by Marcin Kuzniar
- 2018-07-02 Yves Tolosa-Joas: Updated OnurAir Liveries & Traffic
- 2018-07-07 Yves Tolosa-Joas: Updated Liveries and Traffic for AviaTraffic Kyrgyzstan
- 2018-07-10 Yves Tolosa-Joas: Updated Traffic & Liveries for Saudia to June 2018 Timetable
- 2018-08-05 Yves Tolosa-Joas: Replaced Billboard Navigation Lights with Procedural on Airbus AI Aircrafts
- 2018-08-07 Yves Tolosa-Joas: Added Liveries & Traffic for Israir Airlines
- 2018-08-12 Yves Tolosa-Joas: Added Corendon Liveries by Brett Harrison
- 2018-09-10 Yves Tolosa-Joas: Added AirAsiaIndia Livery
- 2018-09-18 Yves Tolosa-Joas: Added Ellinair Airbus' liveries
- 2019-01-27 Yves Tolosa-Joas: Air Corsica Liveries for AT7 and A320 AI models
- 2019-04-28 Yves Tolosa-Joas: Added Virgin Australia Regional Liveries for AI models
- 2019-05-05 Yves Tolosa-Joas: Livery update to New Design & Colors for Lufthansa AI Fleet
- 2019-10-28 Yves Tolosa-Joas: Updated American Airlines AI Liveries
- 2019-11-22 Yves Tolosa-Joas: Updated Air Canada AI fleet to new Black Livery
- 2019-12-28 Yves Tolosa-Joas: Updated AI Liveries for Alaska Airlines
- 2020-03-08 Yves Tolosa-Joas: Added JetBlue AI Liveries
- 2020-03-09 Yves Tolosa-Joas: Corrected Material and emissive
- 2020-03-12 Yves Tolosa-Joas: Re-aligned entire American Airlines AI Fleet livery colour scheme
- 2020-03-14 Yves Tolosa-Joas: Added Ural Airlines Traffic and Liveries
- 2020-03-22 Yves Tolosa-Joas: Added Uzbekistan AI Liveries
- 2020-03-22 Yves Tolosa-Joas: Simplified AI 320 model and Updated objects naming
- 2020-04-30 Yves Tolosa-Joas: Updated AI Liveries and Traffic for Rossiya
- 2020-05-08 Yves Tolosa-Joas: Updated QantasLink Traffic and Liveries
- 2020-05-21 Lars Toenning: Add Eurowings A320 texture
- 2020-05-24 Yves Tolosa-Joas: Liveries and Traffic for Pakistsn Intl
- 2020-08-16 Stuart Buchanan: Standard gear and light properties for Airbus AI.
- 2020-08-22 Yves Tolosa-Joas: Removed defunct GermanWings Traffic and Liveries
- 2021-05-01 Yves Tolosa-Joas: Added Liveries and Traffic for SATA Air Acores and subsidiary Azores Airlines
- 2021-08-15 Yves Tolosa-Joas: Removed Deprecated LAN & TAM Aircrafts and Liveries now replaced by LATAM
- 2021-08-21 Yves Tolosa-Joas: Avianca Traffic and Liveries
- 2021-09-18 Yves Tolosa-Joas: Updated Liveries for SAS AI models
- 2023-04-17 scttgs0: [AI/Aircraft] PNG compression and iCCP removal
- 2025-03-13 Karel Klimeš: Fix additional inconsistent directory naming in AI/Aircraft/
